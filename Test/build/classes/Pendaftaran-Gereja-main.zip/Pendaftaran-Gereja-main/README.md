# Pendaftaran Gereja
ada 3 menu yang dibuat :
.[Daftar Misa](#Daftar-Misa)
.[Daftar Umat](#Daftar-Umat)
.[Daftar Kursi](#Daftar-Kursi)

## Daftar-Misa
berupa form pendaftaran misa
## Daftar-Umat
berupa daftar umat terdiri dari tabel
## Daftar-Kursi
berupa daftar kursi dan status kursi
